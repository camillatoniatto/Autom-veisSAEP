﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace saep_prova.Models
{
    public class Alocacao
    {
        public int Id { get; set; }
        public int Area { get; set; }
        public int IdAutomovel { get; set; }
        public int IdConcessionaria { get; set; }
        public int Quantidade { get; set; }
    }
}
