﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace saep_prova.Models
{
    public class Concessionarias
    {
        public int Id { get; set; }
        public string Concessionaria { get; set; }
    }
}
