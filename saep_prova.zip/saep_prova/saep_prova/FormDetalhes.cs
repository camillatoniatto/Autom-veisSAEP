﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace saep_prova
{
    public partial class FormDetalhes : Form
    {
        public FormDetalhes()
        {
            InitializeComponent();
        }

        private void FormDetalhes_Load(object sender, EventArgs e)
        {
            //carregaDetalhe(area);
        }

        public void carregaDetalhe(int area)
        {
            lblArea.Text = area.ToString();

            SqlConnection con = ClassDbContext.ObterConexao();
            string sql = "SELECT Automoveis.modelo FROM Alocacao INNER JOIN Automoveis ON Alocacao.Automovel = Automoveis.Id WHERE area='" + area + "' AND quantidade>0;";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Automoveis");
            cbxCarro.ValueMember = "Id";
            cbxCarro.DisplayMember = "modelo".Trim();
            cbxCarro.DataSource = ds.Tables["Automoveis"];
            con.Close();
        }

        private void btnVender_Click(object sender, EventArgs e)
        {
            FormVenda venda = new FormVenda();
            venda.CarregaConcessionaria(Convert.ToInt32(lblArea.Text), cbxCarro.Text);
            venda.Show();
        }
    }
}
