﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace saep_prova
{
    public partial class FormVenda : Form
    {
        public FormVenda()
        {
            InitializeComponent();
        }

        private void CarregaCliente()
        {
            SqlConnection con = ClassDbContext.ObterConexao();
            string sql = "SELECT * From Clientes ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Clientes");
            cbxCliente.ValueMember = "Id";
            cbxCliente.DisplayMember = "nome".Trim();
            cbxCliente.DataSource = ds.Tables["Clientes"];
            con.Close();
        }

        public void CarregaConcessionaria(int area, string modelo)
        {
            SqlConnection con = ClassDbContext.ObterConexao();
            string sql = "SELECT Concessionarias.concessionaria FROM Automoveis INNER JOIN Alocacao ON Automoveis.Id = Alocacao.Automovel INNER JOIN Concessionarias ON Alocacao.Concessionaria = Concessionarias.Id WHERE area='" + area + "' AND modelo='" + modelo + "' ";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Concessionarias");
            cbxConcessionaria.ValueMember = "Id";
            cbxConcessionaria.DisplayMember = "concessionaria".Trim();
            cbxConcessionaria.DataSource = ds.Tables["Concessionarias"];
            con.Close();
        }

        private void FormVenda_Load(object sender, EventArgs e)
        {
            CarregaCliente();
        }
    }
}
