﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace saep_prova
{
    public partial class FormInicial : Form
    {
        public static int valor = 0;
        public static string texto = "";
        public FormInicial()
        {
            InitializeComponent();
            for (int i = 0; i < 12; i++)
            {
                check(i);
            }
        }

        public void check(int area)
        {
            SqlConnection con = ClassDbContext.ObterConexao();
            string query = "SELECT * FROM Alocacao WHERE area = '" + area + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dtable = new DataTable();
            sda.Fill(dtable);

            if (dtable.Rows.Count > 0)
            {
                string color = "#0000FF";
                Color myColor = System.Drawing.ColorTranslator.FromHtml(color);

                switch (area)
                {
                    case 1:
                        btn1.BackColor = myColor;
                        btn1.Enabled = true;
                        break;
                    case 2:
                        btn2.BackColor = myColor;
                        btn2.Enabled = true;
                        break;
                    case 3:
                        btn3.BackColor = myColor;
                        btn3.Enabled = true;
                        break;
                    case 4:
                        btn4.BackColor = myColor;
                        btn4.Enabled = true;
                        break;
                    case 5:
                        btn5.BackColor = myColor;
                        btn5.Enabled = true;
                        break;
                    case 6:
                        btn6.BackColor = myColor;
                        btn6.Enabled = true;
                        break;
                    case 7:
                        btn7.BackColor = myColor;
                        btn7.Enabled = true;
                        break;
                    case 8:
                        btn8.BackColor = myColor;
                        btn8.Enabled = true;
                        break;
                    case 9:
                        btn9.BackColor = myColor;
                        btn9.Enabled = true;
                        break;
                    case 10:
                        btn10.BackColor = myColor;
                        btn10.Enabled = true;
                        break;
                    case 11:
                        btn11.BackColor = myColor;
                        btn11.Enabled = true;
                        break;
                }
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            valor = 1;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            valor = 2;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            valor = 3;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            valor = 4;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            valor = 5;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            valor = 6;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            valor = 7;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            valor = 8;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            valor = 9;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            valor = 10;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }

        private void btn11_Click(object sender, EventArgs e)
        {
            valor = 11;
            FormDetalhes detalhes = new FormDetalhes();
            detalhes.carregaDetalhe(valor);
            detalhes.Show();
        }
    }
}
